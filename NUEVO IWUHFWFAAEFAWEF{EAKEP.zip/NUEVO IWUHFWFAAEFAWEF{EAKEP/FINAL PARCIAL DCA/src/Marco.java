import java.util.ArrayList;

import processing.core.PApplet;

public class Marco extends Entity 
{
	PApplet app;
  private Polo pl;
  //private World w;
  
  public Marco(float x, float y, float time, String colorA,String colorB,String dir, String msg, PApplet app)
  {
	  super(x, y, time, colorA, colorB, dir, msg, app);
   // super(x,y,10,"blue","blue","left","Marco");
    //this.w = w;
	  //w = new World(20, app);
	// w = new World (1,app);
  }
  
  
  public void request(ArrayList<Polo> a)
  {
    Polo aux = null;
    if (a.size()> 0) 
    {
      aux = a.get(0);
      aux.setWanted(true);
    }
    
    for (int i = 0; i < a.size(); i++)
    {
      Polo b = a.get(i);
      if (PApplet.dist(super.x,super.y,aux.getPosition()[0],getPosition()[1])> PApplet.dist(super.x,super.y,b.getPosition()[0], b.getPosition()[1]))
      {
        aux.setWanted(false);
        aux = b;
        aux.setWanted(true);
      }
    }
    
    pl = aux;
    
    float a1 = 0;
    float a2 = 0;
    
    if (pl != null)
    {
      if (super.getX() < pl.getPosition()[0])
    {
      a1 = 2;
      
    }else if (super.getX() > pl.getPosition()[0])
    {
      a1 = -2;
    }
    
    if (super.getY() < pl.getPosition()[1])
    {
      a2 = 2;
      
    }else if (super.getY() > pl.getPosition()[1])
    {
      a2 = -2;
    }
  }
    
    super.dir[0] = a1;
    super.dir[1] = a2;
  }
  
  @Override
  public void move(float a, float b)
  {
    
    
    super.x += super.dir[0];
    super.y += super.dir[1];
    
    super.rebote();
    
   // w.deletePolo();
    
    
  }
  
  
  
  
  
  
}