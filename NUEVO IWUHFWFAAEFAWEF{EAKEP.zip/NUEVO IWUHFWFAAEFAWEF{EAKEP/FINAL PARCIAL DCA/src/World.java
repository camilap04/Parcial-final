import java.util.ArrayList;

import processing.core.PApplet;

public class World implements Runnable{
	PApplet app;
  private Marco m;
  private ArrayList<Polo> polos;
  private String s;
  
  public World(int n, PApplet app)
  {
    
	this.app = app;  
	createPolos(n);
    m = new Marco(app.random(20,700),app.random(20,700),10,"blue","blue","left","Marco",app);
    
    //x,y,10,"blue","blue","left","Marco"
    new Thread (m).start();
    s = "";
  }
  
  @Override
  public void run()
  {
      while(polos.size()> 0)
      {
        
        if (s.isEmpty()) s = "not empty";
        else s = "";
        m.request(polos);
      try
      {
        
        Thread.sleep(2000);
        
      }catch (Exception e)
      {
       
      }
      
      }
  }
  
  
  
  
  public void createPolos(int n)
  {
    polos = new ArrayList<Polo>();
    for (int i = 0; i < n; i++)
    {
      int b = (int)app.random(1,5);
      String dr = "";
      switch (b)
      {
        case 1: dr = "up"; break;
        case 2: dr = "down"; break;
        case 3: dr = "left"; break;
        case 4: dr = "right"; break; 
        default: dr = "right"; break;
      }
      
 
      Polo a = new Polo(app.random(20,700),app.random(20,700),20,"green","green",dr,"Polo", app);
      //Polo a = new Polo(app.random(20,700),app.random(20,700),dr);
      polos.add(a);
      new Thread (a).start();
    }
  }
  
  public ArrayList<Polo> getPolos()
  {
    return polos;
  }
  
  public Marco getMarco()
  {
    return m;
  }
  
  
  public void draw()
  {
    for (int i = 0; i < polos.size(); i++)
    {
       polos.get(i).draw(s);
      
      
    }
    
     m.draw(s);
    deletePolo();
    
  }
  
  
  
  
  
  public void deletePolo()
  {
    Polo unWished = null;
    float x = m.getPosition()[0];
    float y = m.getPosition()[1];
    for (int i = 0; i < polos.size(); i++)
    {
      if (PApplet.dist(x,y,polos.get(i).getPosition()[0], polos.get(i).getPosition()[1]) <39)
      {
        unWished = polos.get(i);
      }
    }
    
    if (unWished != null) polos.remove(unWished);
  }
  
  
  
}