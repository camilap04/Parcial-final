import processing.core.PApplet;

public class Principal extends PApplet {
	World world;

	public static void main(String[] args) {
		PApplet.main(Principal.class.getName());
	}

	public void settings() {
		size(800, 800);
	}

	public void setup() {
		world = new World(50, this);

		new Thread (world).start();

	}

	public void draw() {

		background(255, 255, 255);

		world.draw();
	}
}