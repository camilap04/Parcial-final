import processing.core.PApplet;

public class Polo extends Entity {
	PApplet app;
	private boolean isWanted;
	private float seconds;

	public Polo(float x, float y, float time, String colorA, String colorB, String dir, String msg, PApplet app) {
		super(x, y, time, colorA, colorB, dir, msg, app);
		// super(x,y,20,"green","green",dir,"Polo");
		isWanted = false;
		seconds = 0;

	}

	public void setWanted(boolean a) {
		isWanted = a;
	}

	@Override
	public void move(float a, float b) {

		super.x += super.dir[0];
		super.y += super.dir[1];

		super.rebote();

		if (isWanted) {

			if (seconds == 150) {
				changeDir((int) app.random(0, 3));
				seconds = 0;

			} else {
				seconds += 20;
			}
		}

	}

}
