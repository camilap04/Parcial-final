import processing.core.PApplet;
import processing.core.PFont;

public class Entity implements Runnable
{
  

	PApplet app;
  protected float x;
protected float y;
  private float time;
  private int[] colorA;
  private int[] colorB;
  protected float[] dir;
  private String msg;
  
  public Entity(float x, float y, float time, String colorA,String colorB,String dir, String msg, PApplet app)
  {
    this.x = x;
    this.y = y;
    this.time = time;
    this.colorA = convertColor(colorA);
    this.colorB = convertColor(colorB);
    this.dir = parseDir(dir);
    this.msg = msg;
    this.app = app;
  }
  
  @Override
  public void run(){
    while (true)
    {
      move(dir[0],dir[1]);
    try
    {
      Thread.sleep((long)time);
      
    } catch (InterruptedException e) {
      
        e.printStackTrace();
        
    }
    }
  }
  
  public void draw(String s)
  {
    int a = app.color(colorA[0],colorA[1],colorA[2]);
    int b = app.color(colorB[0],colorB[1],colorB[2]);
    
    app.fill(a);
    app.stroke(b);
    app.circle(x,y,40);
      
    
    if (!s.isEmpty())
    {
      PFont f = app.createFont("Arial",15);
      app.textFont(f);
      String aux = msg+x+" "+y;
      app.text(aux,x-20, y+40);
    }
  }
  
  public void move(float a, float b)
  {
    x+= a;
    y+= b;
  }
  
  
  
  
  public int[] convertColor(String a)
  {
    int[] r = new int[3];
    switch (a)
    {
      case "white":
        r[0] = 255;
        r[1] = 255;
        r[2] = 255;
        break;
      case "green":
        r[0] = 0;
        r[1] = 255;
        r[2] = 0;
        break;
      case "blue":
        r[0] = 0;
        r[1] = 0;
        r[2] = 255;
    }
    return r;
  }
  
  
  
  
  
  public float[] getPosition()
  {
    float[] r = {x,y};
    
    return r;
  }
  
  public float[] parseDir(String a)
  {
    
    float[] r = new float[2];
    switch(a)
    {
      case "up": 
      r[0] = 0;
      r[1] = 2;
      break;
      case "down":
      r[0] = 0;
      r[1] = -2;
      break;
      case "left":
      r[0] = -2;
      r[1] = 0;
      break;
      case "right":
      r[0] = 2;
      r[1] = 0;
      break;
    }
    
    return r;
  }
  
  public void changeDir(int a)
  {
    switch (a)
    {
      case 1: 
      if (dir.equals(parseDir("up")))
      {
        dir = parseDir("down");
      }else 
      {
        dir = parseDir("up");
      }
      
      break;
      case 2:
      if (dir.equals(parseDir("left")))
      {
        dir = parseDir("right");
      }else
      {
        dir = parseDir("left");
      }
      
      break;
      default: changeDir(1);
    }
  }
  
  public void changeDir(float a, float b)
  {
    dir[0] = a;
    dir[1] = b;
  }
  
  public void rebote()
  {
    if (x >= 800)
    {
      dir[0] = -2;
    }else if (x <= 0)
    {
      dir[0] = 2;
    }
    
    if (y >= 800)
    {
      dir[1] = -2;
    }else if (y <= 0)
    {
      dir[1] = 2;
    }
    
    if (PApplet.dist(x,y,0,800) < 15)
    {
      dir[0] =  app.random(0,2);
      dir[1] = app.random(0,-2);
    }
    
    if (PApplet.dist(x,y,800,0) < 15)
    {
      dir[0] =  app.random(0,-2);
      dir[1] = app.random(0,2);
    }
    
     if (PApplet.dist(x,y,0,0) < 15)
    {
      dir[0] =  app.random(0,2);
      dir[1] = app.random(0,2);
    }
    
     if (PApplet.dist(x,y,800,800) < 15)
    {
      dir[0] =  app.random(0,-2);
      dir[1] = app.random(0,-2);
    }
    
  }
  
  public float getX()
  {
    return x;
  }
  
  public void setX(float x)
  {
    this.x = x;
  }
  
  public float getY()
  {
    return y;
  }
  
  public void setY(float y)
  {
    this.y = y;
  }
  
  
  
}